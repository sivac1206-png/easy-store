import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../providers/cart_provider.dart';
import '../screens/product_details_screen.dart';

class ProductCard extends StatelessWidget {
  final Product product;
  const ProductCard({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final q = cart.quantity(product);

    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ProductDetailsScreen(product: product)),
      ),
      child: Container(
        width: 170,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.black.withOpacity(.05)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 105,
              width: double.infinity,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0xFFF0F8F0),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(product.emoji, style: const TextStyle(fontSize: 58)),
            ),
            const SizedBox(height: 10),
            Text(product.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 3),
            Text(product.unit, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
            const SizedBox(height: 7),
            Row(
              children: [
                Text('₹${product.price.toStringAsFixed(0)}',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                if (product.oldPrice > product.price) ...[
                  const SizedBox(width: 5),
                  Text('₹${product.oldPrice.toStringAsFixed(0)}',
                      style: TextStyle(decoration: TextDecoration.lineThrough,
                          color: Colors.grey.shade500, fontSize: 11)),
                ],
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: q == 0
                  ? OutlinedButton(
                      onPressed: () => context.read<CartProvider>().add(product),
                      child: const Text('ADD'),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(onPressed: () => context.read<CartProvider>().remove(product),
                            icon: const Icon(Icons.remove_circle_outline)),
                        Text('$q', style: const TextStyle(fontWeight: FontWeight.bold)),
                        IconButton(onPressed: () => context.read<CartProvider>().add(product),
                            icon: const Icon(Icons.add_circle_outline)),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
