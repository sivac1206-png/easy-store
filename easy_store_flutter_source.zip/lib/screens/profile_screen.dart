import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override Widget build(BuildContext context) => SafeArea(
    child: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Profile', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
      const SizedBox(height: 20),
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
        child: const Row(children: [CircleAvatar(radius: 30, child: Icon(Icons.person)), SizedBox(width: 14), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Easy Store Customer', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)), Text('Manage your account')])])),
      const SizedBox(height: 15),
      const _Item(Icons.receipt_long, 'My Orders'),
      const _Item(Icons.location_on_outlined, 'Saved Addresses'),
      const _Item(Icons.account_balance_wallet_outlined, 'Payments'),
      const _Item(Icons.support_agent, 'Help & Support'),
      const _Item(Icons.settings_outlined, 'Settings'),
    ]),
  );
}
class _Item extends StatelessWidget {
  final IconData icon; final String text;
  const _Item(this.icon, this.text);
  @override Widget build(BuildContext context) => ListTile(contentPadding: EdgeInsets.zero, leading: Icon(icon), title: Text(text), trailing: const Icon(Icons.chevron_right));
}
