import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../providers/cart_provider.dart';

class ProductDetailsScreen extends StatelessWidget {
  final Product product;
  const ProductDetailsScreen({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    final q = context.watch<CartProvider>().quantity(product);
    return Scaffold(
      appBar: AppBar(title: const Text('Product Details')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(height: 280, alignment: Alignment.center,
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)),
          child: Text(product.emoji, style: const TextStyle(fontSize: 140))),
        const SizedBox(height: 20),
        Text(product.name, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
        Text(product.unit, style: const TextStyle(color: Colors.grey)),
        const SizedBox(height: 12),
        Row(children: [
          Text('₹${product.price.toStringAsFixed(0)}', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
          const SizedBox(width: 10),
          if (product.oldPrice > product.price) Text('₹${product.oldPrice.toStringAsFixed(0)}', style: const TextStyle(decoration: TextDecoration.lineThrough, color: Colors.grey)),
        ]),
        const SizedBox(height: 18),
        const Text('Fresh quality product. Packed carefully and delivered quickly to your doorstep.', style: TextStyle(height: 1.5, color: Colors.black87)),
        const SizedBox(height: 30),
        SizedBox(height: 54, child: ElevatedButton(
          onPressed: () {
            context.read<CartProvider>().add(product);
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Added to cart')));
          },
          child: Text(q == 0 ? 'Add to Cart' : 'Add One More • $q in Cart'),
        )),
      ]),
    );
  }
}
