import 'package:flutter/material.dart';
import '../models/product.dart';
import '../widgets/product_card.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});
  @override State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  String selected = 'All';
  final categories = const ['All','Fruits','Vegetables','Dairy','Staples','Snacks','Drinks','Personal Care'];

  @override
  Widget build(BuildContext context) {
    final shown = selected == 'All' ? products : products.where((p) => p.category == selected).toList();
    return SafeArea(
      child: CustomScrollView(slivers: [
        const SliverAppBar(title: Text('Categories'), floating: true),
        SliverToBoxAdapter(child: SizedBox(height: 52, child: ListView.separated(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          scrollDirection: Axis.horizontal, itemCount: categories.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, i) => ChoiceChip(label: Text(categories[i]), selected: selected == categories[i],
            onSelected: (_) => setState(() => selected = categories[i])),
        ))),
        SliverPadding(padding: const EdgeInsets.all(18), sliver: SliverGrid(
          delegate: SliverChildBuilderDelegate((_, i) => ProductCard(product: shown[i]), childCount: shown.length),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisExtent: 285, crossAxisSpacing: 12, mainAxisSpacing: 12),
        )),
      ]),
    );
  }
}
