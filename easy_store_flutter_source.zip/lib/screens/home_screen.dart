import 'package:flutter/material.dart';
import '../models/product.dart';
import '../widgets/product_card.dart';
import 'search_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final popular = products.where((p) => p.popular).toList();
    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 0),
            sliver: SliverToBoxAdapter(
              child: Row(
                children: [
                  const Icon(Icons.location_on, color: Color(0xFF16A34A)),
                  const SizedBox(width: 7),
                  const Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Deliver to', style: TextStyle(fontSize: 11, color: Colors.grey)),
                      Text('Home • Salem, Tamil Nadu', style: TextStyle(fontWeight: FontWeight.w800)),
                    ],
                  )),
                  IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 0),
            sliver: SliverToBoxAdapter(
              child: GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchScreen())),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                  child: const Row(children: [
                    Icon(Icons.search, color: Colors.grey),
                    SizedBox(width: 10),
                    Text('Search groceries, fruits, snacks...', style: TextStyle(color: Colors.grey)),
                  ]),
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(18),
            sliver: SliverToBoxAdapter(
              child: Container(
                height: 160,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: const LinearGradient(colors: [Color(0xFF16A34A), Color(0xFF65C96F)]),
                ),
                child: Row(
                  children: [
                    const Expanded(child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('Groceries at your\nDoorstep', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900)),
                        SizedBox(height: 7),
                        Text('Fresh products. Fast delivery.', style: TextStyle(color: Colors.white70)),
                        SizedBox(height: 12),
                        Chip(label: Text('SHOP NOW'), backgroundColor: Colors.white),
                      ],
                    )),
                    const Text('🛍️', style: TextStyle(fontSize: 65)),
                  ],
                ),
              ),
            ),
          ),
          const SliverPadding(
            padding: EdgeInsets.symmetric(horizontal: 18),
            sliver: SliverToBoxAdapter(child: Text('Shop by Category', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 22),
            sliver: SliverToBoxAdapter(
              child: SizedBox(
                height: 94,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: const [
                    _Category(emoji:'🍎', name:'Fruits'),
                    _Category(emoji:'🥦', name:'Vegetables'),
                    _Category(emoji:'🥛', name:'Dairy'),
                    _Category(emoji:'🌾', name:'Staples'),
                    _Category(emoji:'🍪', name:'Snacks'),
                    _Category(emoji:'🧴', name:'Care'),
                  ],
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            sliver: SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: const Color(0xFFFFE6D7), borderRadius: BorderRadius.circular(20)),
                child: const Row(children: [
                  Text('🔥', style: TextStyle(fontSize: 32)),
                  SizedBox(width: 10),
                  Expanded(child: Text("Today's Special\nUp to 50% OFF", style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17))),
                  Text('View all →', style: TextStyle(fontWeight: FontWeight.bold)),
                ]),
              ),
            ),
          ),
          const SliverPadding(
            padding: EdgeInsets.fromLTRB(18, 24, 18, 12),
            sliver: SliverToBoxAdapter(child: Text('Best Selling Products', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 285,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                scrollDirection: Axis.horizontal,
                itemCount: popular.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (_, i) => ProductCard(product: popular[i]),
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 24)),
        ],
      ),
    );
  }
}

class _Category extends StatelessWidget {
  final String emoji, name;
  const _Category({required this.emoji, required this.name});
  @override
  Widget build(BuildContext context) => Container(
    width: 78, margin: const EdgeInsets.only(right: 10),
    child: Column(children: [
      Container(height: 62, width: 62, alignment: Alignment.center,
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
        child: Text(emoji, style: const TextStyle(fontSize: 31))),
      const SizedBox(height: 6),
      Text(name, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
    ]),
  );
}
