import 'package:flutter/material.dart';

class OrderTrackingScreen extends StatelessWidget {
  const OrderTrackingScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Track Order')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Container(height: 180, alignment: Alignment.center, decoration: BoxDecoration(color: const Color(0xFFE9F7EC), borderRadius: BorderRadius.circular(24)),
        child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text('🛵', style: TextStyle(fontSize: 55)), SizedBox(height: 8), Text('Arriving in 18–25 min', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900))])),
      const SizedBox(height: 25),
      const Text('Order #ES10248', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
      const SizedBox(height: 18),
      _step(Icons.check_circle, 'Order Confirmed', 'Your order has been placed'),
      _step(Icons.inventory_2, 'Packing', 'Store is preparing your items'),
      _step(Icons.delivery_dining, 'Out for Delivery', 'Delivery partner is on the way'),
      _step(Icons.home, 'Delivered', 'Estimated delivery soon'),
    ]),
  );

  Widget _step(IconData icon, String title, String subtitle) => ListTile(
    leading: CircleAvatar(backgroundColor: const Color(0xFFE5F6E9), child: Icon(icon, color: const Color(0xFF16A34A))),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
    subtitle: Text(subtitle),
  );
}
