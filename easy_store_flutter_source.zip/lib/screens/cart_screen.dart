import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';
import 'checkout_screen.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    return SafeArea(
      child: Column(children: [
        const Padding(padding: EdgeInsets.all(18), child: Align(alignment: Alignment.centerLeft, child: Text('My Cart', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)))),
        if (cart.productsInCart.isEmpty)
          const Expanded(child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('🛒', style: TextStyle(fontSize: 64)), SizedBox(height: 10),
            Text('Your cart is empty', style: TextStyle(fontWeight: FontWeight.bold)),
          ])))
        else Expanded(child: Column(children: [
          Expanded(child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            itemCount: cart.productsInCart.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (_, i) {
              final p = cart.productsInCart[i]; final q = cart.quantity(p);
              return Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
                child: Row(children: [
                  Text(p.emoji, style: const TextStyle(fontSize: 42)), const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text('₹${p.price.toStringAsFixed(0)} × $q'),
                  ])),
                  IconButton(onPressed: () => cart.remove(p), icon: const Icon(Icons.remove_circle_outline)),
                  Text('$q', style: const TextStyle(fontWeight: FontWeight.bold)),
                  IconButton(onPressed: () => cart.add(p), icon: const Icon(Icons.add_circle_outline)),
                ]));
            },
          )),
          Container(padding: const EdgeInsets.fromLTRB(18, 15, 18, 18), color: Colors.white,
            child: Column(children: [
              _row('Subtotal', cart.subtotal), _row('Delivery', cart.deliveryFee),
              const Divider(), _row('Total', cart.total, bold: true),
              const SizedBox(height: 12),
              SizedBox(width: double.infinity, height: 52, child: ElevatedButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CheckoutScreen())),
                child: Text('Checkout • ₹${cart.total.toStringAsFixed(0)}'),
              )),
            ])),
        ])),
      ]),
    );
  }

  Widget _row(String label, double value, {bool bold = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: TextStyle(fontWeight: bold ? FontWeight.w900 : FontWeight.normal)),
      Text('₹${value.toStringAsFixed(0)}', style: TextStyle(fontWeight: bold ? FontWeight.w900 : FontWeight.normal)),
    ]),
  );
}
