import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';
import 'order_tracking_screen.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});
  @override State<CheckoutScreen> createState() => _CheckoutScreenState();
}
class _CheckoutScreenState extends State<CheckoutScreen> {
  String payment = 'UPI';
  @override Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Checkout')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const Text('Delivery Address', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
          child: const Row(children: [Icon(Icons.home, color: Color(0xFF16A34A)), SizedBox(width: 12), Expanded(child: Text('Home\nSalem, Tamil Nadu', style: TextStyle(fontWeight: FontWeight.w700, height: 1.5))), Text('Change')])) ,
        const SizedBox(height: 24),
        const Text('Payment Method', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
        ...['UPI','Card','Cash on Delivery'].map((p) => RadioListTile<String>(value: p, groupValue: payment, title: Text(p), onChanged: (v) => setState(() => payment = v!))),
        const SizedBox(height: 14),
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
          child: Column(children: [
            _row('Subtotal', cart.subtotal), _row('Delivery', cart.deliveryFee),
            const Divider(), _row('Payable', cart.total, bold: true),
          ])),
        const SizedBox(height: 20),
        SizedBox(height: 54, child: ElevatedButton(
          onPressed: () {
            cart.clear();
            Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const OrderTrackingScreen()), (r) => r.isFirst);
          },
          child: Text('Place Order • ₹${cart.total.toStringAsFixed(0)}'),
        )),
      ]),
    );
  }
  Widget _row(String a, double b, {bool bold=false}) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(a, style: TextStyle(fontWeight: bold ? FontWeight.w900 : null)), Text('₹${b.toStringAsFixed(0)}', style: TextStyle(fontWeight: bold ? FontWeight.w900 : null))]));
}
