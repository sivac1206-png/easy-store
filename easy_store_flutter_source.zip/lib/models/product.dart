class Product {
  final String id;
  final String name;
  final String category;
  final String unit;
  final double price;
  final double oldPrice;
  final String emoji;
  final bool popular;

  const Product({
    required this.id,
    required this.name,
    required this.category,
    required this.unit,
    required this.price,
    this.oldPrice = 0,
    required this.emoji,
    this.popular = false,
  });

  int get discountPercent =>
      oldPrice > price ? ((oldPrice - price) / oldPrice * 100).round() : 0;
}

const products = <Product>[
  Product(id:'p1', name:'Banana', category:'Fruits', unit:'1 kg', price:42, oldPrice:50, emoji:'🍌', popular:true),
  Product(id:'p2', name:'Tomato', category:'Vegetables', unit:'1 kg', price:28, oldPrice:36, emoji:'🍅', popular:true),
  Product(id:'p3', name:'Potato', category:'Vegetables', unit:'1 kg', price:35, oldPrice:42, emoji:'🥔'),
  Product(id:'p4', name:'Amul Taaza Milk', category:'Dairy', unit:'1 L', price:54, oldPrice:58, emoji:'🥛', popular:true),
  Product(id:'p5', name:'Aashirvaad Atta', category:'Staples', unit:'5 kg', price:315, oldPrice:350, emoji:'🌾', popular:true),
  Product(id:'p6', name:'Basmati Rice', category:'Staples', unit:'5 kg', price:499, oldPrice:560, emoji:'🍚'),
  Product(id:'p7', name:'Tata Salt', category:'Staples', unit:'1 kg', price:28, oldPrice:30, emoji:'🧂'),
  Product(id:'p8', name:'Potato Chips', category:'Snacks', unit:'100 g', price:20, oldPrice:25, emoji:'🥔'),
  Product(id:'p9', name:'Orange Juice', category:'Drinks', unit:'1 L', price:110, oldPrice:125, emoji:'🧃'),
  Product(id:'p10', name:'Shampoo', category:'Personal Care', unit:'650 ml', price:299, oldPrice:349, emoji:'🧴'),
  Product(id:'p11', name:'Eggs', category:'Dairy', unit:'12 pcs', price:78, oldPrice:90, emoji:'🥚'),
  Product(id:'p12', name:'Apples', category:'Fruits', unit:'1 kg', price:149, oldPrice:175, emoji:'🍎'),
];
