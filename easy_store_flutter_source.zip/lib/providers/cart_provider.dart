import 'package:flutter/foundation.dart';
import '../models/product.dart';

class CartProvider extends ChangeNotifier {
  final Map<String, int> _items = {};

  Map<String, int> get items => Map.unmodifiable(_items);

  int quantity(Product product) => _items[product.id] ?? 0;

  List<Product> get productsInCart =>
      products.where((p) => _items.containsKey(p.id)).toList();

  int get itemCount => _items.values.fold(0, (a, b) => a + b);

  double get subtotal => productsInCart.fold(
        0,
        (sum, p) => sum + p.price * (_items[p.id] ?? 0),
      );

  double get deliveryFee => subtotal == 0 || subtotal >= 499 ? 0 : 29;
  double get total => subtotal + deliveryFee;

  void add(Product product) {
    _items[product.id] = quantity(product) + 1;
    notifyListeners();
  }

  void remove(Product product) {
    final q = quantity(product);
    if (q <= 1) {
      _items.remove(product.id);
    } else {
      _items[product.id] = q - 1;
    }
    notifyListeners();
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }
}
